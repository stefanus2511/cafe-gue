/**
 * Kopi Kita — Cloud Functions
 * -----------------------------------------------------------------------
 * Semua tulis-menulis data sensitif (harga, stok, status pesanan, status
 * pembayaran) terjadi DI SINI, bukan di frontend. Frontend hanya boleh
 * membaca (lihat firestore.rules) dan memanggil fungsi-fungsi callable ini.
 * -----------------------------------------------------------------------
 */
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { setGlobalOptions } = require("firebase-functions/v2");
const admin = require("firebase-admin");
const fetch = require("node-fetch");

admin.initializeApp();
const db = admin.firestore();
setGlobalOptions({ region: "asia-southeast2", maxInstances: 10 }); // Jakarta

const TAX_RATE = 0.10;
const SERVICE_FEE_RATE = 0;
const ORDER_TTL_MIN = 30; // pesanan QRIS yang belum dibayar dianggap kedaluwarsa setelah ini

// ---------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------

function requireStaff(auth) {
  if (!auth || !["kasir", "admin"].includes(auth.token?.role)) {
    throw new HttpsError("permission-denied", "Hanya kasir/admin yang boleh melakukan ini.");
  }
}
function requireAdmin(auth) {
  if (!auth || auth.token?.role !== "admin") {
    throw new HttpsError("permission-denied", "Hanya admin yang boleh melakukan ini.");
  }
}

async function writeAudit(actorUid, actorName, action, orderId) {
  await db.collection("auditLogs").add({
    userId: actorUid || "system",
    actorName: actorName || "Sistem",
    action,
    orderId: orderId || null,
    timestamp: admin.firestore.FieldValue.serverTimestamp(),
  });
}

function genOrderNumber(seq) {
  return "A-" + String(seq).padStart(3, "0");
}

/**
 * EMVCo CRC16-CCITT (polynomial 0x1021, init 0xFFFF) — dipakai QRIS.
 */
function crc16ccitt(str) {
  let crc = 0xffff;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
      crc &= 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

/** Parse TLV (tag-length-value) sederhana sesuai spesifikasi EMVCo QR. */
function parseTLV(payload) {
  const out = [];
  let i = 0;
  while (i < payload.length - 4) { // -4: sisakan CRC di akhir
    const tag = payload.slice(i, i + 2);
    const len = parseInt(payload.slice(i + 2, i + 4), 10);
    const value = payload.slice(i + 4, i + 4 + len);
    out.push({ tag, value });
    i += 4 + len;
  }
  return out;
}
function tlv(tag, value) {
  return tag + String(value.length).padStart(2, "0") + value;
}

/**
 * Ubah QRIS statis menjadi QRIS dinamis dengan nominal tertentu.
 * Tag 01 = Point of Initiation Method: "11" statis, "12" dinamis.
 * Tag 54 = Transaction Amount (hanya ada pada QRIS dinamis).
 * Tag 63 = CRC, harus dihitung ulang dan selalu jadi TLV terakhir.
 */
function buildDynamicQris(staticQris, amountRupiah) {
  const fields = parseTLV(staticQris);
  let out = "";
  let has54Inserted = false;
  for (const f of fields) {
    if (f.tag === "01") {
      out += tlv("01", "12"); // paksa jadi dinamis
      continue;
    }
    if (f.tag === "54") continue; // buang nominal lama kalau ada
    // Tag 54 harus muncul sebelum tag 58 (country code) menurut spesifikasi umum
    if (f.tag === "58" && !has54Inserted) {
      out += tlv("54", String(Math.round(amountRupiah)));
      has54Inserted = true;
    }
    if (f.tag === "63") continue; // CRC lama dibuang, dihitung ulang di akhir
    out += tlv(f.tag, f.value);
  }
  if (!has54Inserted) out += tlv("54", String(Math.round(amountRupiah)));
  out += "6304"; // header CRC, isinya dihitung dari seluruh string termasuk header ini
  const crc = crc16ccitt(out);
  return out + crc;
}

// ---------------------------------------------------------------------
// createOrder — dipanggil dari halaman pelanggan
// ---------------------------------------------------------------------
exports.createOrder = onCall(async (req) => {
  const { tableId, items, paymentMethod } = req.data || {};
  if (!tableId || !Array.isArray(items) || !items.length) {
    throw new HttpsError("invalid-argument", "Data pesanan tidak lengkap.");
  }
  if (!["cash", "qris"].includes(paymentMethod)) {
    throw new HttpsError("invalid-argument", "Metode pembayaran tidak dikenal.");
  }

  const tableSnap = await db.collection("tables").doc(String(tableId)).get();
  if (!tableSnap.exists || tableSnap.data().active === false) {
    throw new HttpsError("failed-precondition", "Meja tidak valid.");
  }

  const result = await db.runTransaction(async (tx) => {
    let subtotal = 0;
    const resolvedItems = [];

    for (const it of items) {
      if (!it.productId || !it.qty || it.qty < 1) {
        throw new HttpsError("invalid-argument", "Item pesanan tidak valid.");
      }
      const pRef = db.collection("products").doc(String(it.productId));
      const pSnap = await tx.get(pRef);
      if (!pSnap.exists) throw new HttpsError("not-found", "Menu tidak ditemukan.");
      const p = pSnap.data();
      if (!p.availability) {
        throw new HttpsError("failed-precondition", `${p.name} sedang habis.`);
      }

      // Harga dihitung ulang dari server, TIDAK percaya harga dari client.
      let price = p.price;
      const chosenLabels = [];
      if (Array.isArray(p.variants) && Array.isArray(it.variantChoices)) {
        p.variants.forEach((group, gi) => {
          const choiceIdx = it.variantChoices[gi] ?? 0;
          const choice = group.choices[choiceIdx];
          if (!choice) throw new HttpsError("invalid-argument", "Pilihan variasi tidak valid.");
          price += choice.priceDelta || 0;
          chosenLabels.push(choice.label);
        });
      }

      if (typeof p.stock === "number") {
        if (p.stock < it.qty) {
          throw new HttpsError("failed-precondition", `Stok ${p.name} tidak cukup.`);
        }
        // Stok BELUM dikurangi di sini — baru dikurangi saat pembayaran
        // dikonfirmasi (lihat confirmCashPayment / markQrisPaid), supaya
        // pesanan yang tidak jadi dibayar tidak mengunci stok selamanya.
      }

      subtotal += price * it.qty;
      resolvedItems.push({
        productId: it.productId,
        name: p.name,
        opts: chosenLabels.join(", "),
        note: (it.note || "").slice(0, 200),
        qty: it.qty,
        price,
      });
    }

    const tax = Math.round(subtotal * TAX_RATE);
    const serviceFee = Math.round(subtotal * SERVICE_FEE_RATE);
    const total = subtotal + tax + serviceFee;

    const counterRef = db.collection("settings").doc("counters");
    const counterSnap = await tx.get(counterRef);
    const seq = (counterSnap.exists ? counterSnap.data().orderSeq : 0) + 1;
    tx.set(counterRef, { orderSeq: seq }, { merge: true });

    const orderRef = db.collection("orders").doc();
    const orderNumber = genOrderNumber(seq);

    const orderData = {
      orderNumber,
      tableId: String(tableId),
      items: resolvedItems,
      subtotal, tax, serviceFee, total,
      paymentMethod,
      paymentStatus: "unpaid",
      orderStatus: "wait", // Menunggu Pembayaran
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      expiresAt: paymentMethod === "qris"
        ? admin.firestore.Timestamp.fromMillis(Date.now() + ORDER_TTL_MIN * 60000)
        : null,
    };
    tx.set(orderRef, orderData);
    return { orderId: orderRef.id, orderNumber, total };
  });

  if (paymentMethod === "qris") {
    await generateQrisForOrder(result.orderId, result.total);
  }

  return result;
});

/** Membuat & menyimpan QRIS dinamis untuk sebuah order (dipanggil internal). */
async function generateQrisForOrder(orderId, amount) {
  const staticQris = process.env.CAFE_QRIS_STATIC;
  if (!staticQris) {
    throw new HttpsError("failed-precondition", "QRIS statis café belum dikonfigurasi di server.");
  }
  const dynamicQris = buildDynamicQris(staticQris, amount);
  const trxId = orderId; // dipakai sebagai referensi unik saat mencocokkan mutasi
  await db.collection("payments").add({
    orderId,
    provider: "qrisku.my.id",
    providerTransactionId: trxId,
    amount,
    status: "pending",
    qrisString: dynamicQris,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  await db.collection("orders").doc(orderId).update({ qrisString: dynamicQris });
}

// ---------------------------------------------------------------------
// pollQrisPayment — dipanggil berkala oleh halaman pelanggan (mis. tiap
// 5 detik) selama status masih "wait" dan metode "qris".
//
// !! BAGIAN INI BERISI TEBAKAN FORMAT API qrisku.my.id !!
// Situs itu tidak mempublikasikan dokumentasi yang bisa saya baca dari sini.
// Setelah Anda punya akun & dokumentasi resmi, sesuaikan:
//   - URL endpoint (QRISKU_BASE_URL + path)
//   - Nama header/parameter untuk API key
//   - Bentuk response (di mana nominal & status transaksi berada)
// ---------------------------------------------------------------------
exports.pollQrisPayment = onCall(async (req) => {
  const { orderId } = req.data || {};
  if (!orderId) throw new HttpsError("invalid-argument", "orderId wajib diisi.");

  const orderRef = db.collection("orders").doc(orderId);
  const orderSnap = await orderRef.get();
  if (!orderSnap.exists) throw new HttpsError("not-found", "Pesanan tidak ditemukan.");
  const order = orderSnap.data();

  if (order.paymentStatus === "paid") return { status: "paid" };
  if (order.paymentMethod !== "qris") throw new HttpsError("failed-precondition", "Bukan pesanan QRIS.");
  if (order.expiresAt && order.expiresAt.toMillis() < Date.now()) {
    await orderRef.update({ orderStatus: "cancel", updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    return { status: "expired" };
  }

  const apiKey = process.env.QRISKU_API_KEY;
  const baseUrl = process.env.QRISKU_BASE_URL;
  if (!apiKey || !baseUrl) {
    // Belum dikonfigurasi — jangan pura-pura sukses, cukup laporkan menunggu.
    return { status: "pending", note: "Integrasi qrisku.my.id belum dikonfigurasi." };
  }

  try {
    // TODO: ganti path & auth sesuai dokumentasi qrisku.my.id yang sebenarnya.
    const resp = await fetch(`${baseUrl}/mutasi?amount=${order.total}`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (!resp.ok) throw new Error(`qrisku HTTP ${resp.status}`);
    const data = await resp.json();

    // TODO: sesuaikan dengan bentuk response asli. Asumsi sementara:
    // { transactions: [{ amount: number, reference: string, time: string }, ...] }
    const match = (data.transactions || []).find(
      (t) => Number(t.amount) === order.total
    );

    if (match) {
      await markOrderPaidFromQris(orderRef, order, match.reference || match.id || "qrisku-" + Date.now());
      return { status: "paid" };
    }
    return { status: "pending" };
  } catch (err) {
    console.error("pollQrisPayment error:", err);
    // Gagal menghubungi qrisku tidak boleh membuat pesanan otomatis lunas.
    return { status: "pending", error: "Gagal memeriksa status pembayaran." };
  }
});

async function markOrderPaidFromQris(orderRef, order, reference) {
  await db.runTransaction(async (tx) => {
    const fresh = await tx.get(orderRef);
    if (fresh.data().paymentStatus === "paid") return; // anti-duplikat
    for (const item of order.items) {
      const pRef = db.collection("products").doc(item.productId);
      const pSnap = await tx.get(pRef);
      if (!pSnap.exists) continue;
      const p = pSnap.data();
      if (typeof p.stock === "number") {
        const newStock = Math.max(0, p.stock - item.qty);
        tx.update(pRef, { stock: newStock, availability: newStock > 0 ? p.availability : false });
      }
    }
    tx.update(orderRef, {
      paymentStatus: "paid",
      orderStatus: "proc",
      paidAt: admin.firestore.FieldValue.serverTimestamp(),
      paymentReference: reference,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });
  await db.collection("payments").where("orderId", "==", orderRef.id).limit(1).get()
    .then((qs) => qs.forEach((d) => d.ref.update({ status: "paid", paidAt: admin.firestore.FieldValue.serverTimestamp() })));
  await writeAudit(null, "Sistem (QRIS)", "Pembayaran QRIS lunas", order.orderNumber);
}

// Cadangan: cek semua order QRIS "wait" tiap menit (kalau pelanggan menutup halaman
// sebelum polling client sempat mendeteksi pembayaran).
exports.pollQrisPaymentScheduled = onSchedule("every 1 minutes", async () => {
  const apiKey = process.env.QRISKU_API_KEY;
  const baseUrl = process.env.QRISKU_BASE_URL;
  if (!apiKey || !baseUrl) return;

  const waiting = await db.collection("orders")
    .where("orderStatus", "==", "wait")
    .where("paymentMethod", "==", "qris")
    .get();

  for (const doc of waiting.docs) {
    const order = doc.data();
    if (order.expiresAt && order.expiresAt.toMillis() < Date.now()) {
      await doc.ref.update({ orderStatus: "cancel" });
      continue;
    }
    try {
      const resp = await fetch(`${baseUrl}/mutasi?amount=${order.total}`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      if (!resp.ok) continue;
      const data = await resp.json();
      const match = (data.transactions || []).find((t) => Number(t.amount) === order.total);
      if (match) await markOrderPaidFromQris(doc.ref, order, match.reference || "qrisku-" + Date.now());
    } catch (e) {
      console.error("scheduled poll error", order.orderNumber, e);
    }
  }
});

// ---------------------------------------------------------------------
// confirmCashPayment — kasir menekan "Konfirmasi Pembayaran" (tunai/debit)
// ---------------------------------------------------------------------
exports.confirmCashPayment = onCall(async (req) => {
  requireStaff(req.auth);
  const { orderId, method } = req.data || {};
  if (!orderId || !["tunai", "debit"].includes(method)) {
    throw new HttpsError("invalid-argument", "Data tidak lengkap.");
  }
  const orderRef = db.collection("orders").doc(orderId);

  await db.runTransaction(async (tx) => {
    const snap = await tx.get(orderRef);
    if (!snap.exists) throw new HttpsError("not-found", "Pesanan tidak ditemukan.");
    const order = snap.data();
    if (order.paymentStatus === "paid") {
      throw new HttpsError("failed-precondition", "Pesanan ini sudah lunas.");
    }
    if (order.orderStatus !== "wait") {
      throw new HttpsError("failed-precondition", "Pesanan tidak dalam status menunggu pembayaran.");
    }
    for (const item of order.items) {
      const pRef = db.collection("products").doc(item.productId);
      const pSnap = await tx.get(pRef);
      if (!pSnap.exists) continue;
      const p = pSnap.data();
      if (typeof p.stock === "number") {
        if (p.stock < item.qty) {
          throw new HttpsError("failed-precondition", `Stok ${p.name} tidak cukup lagi.`);
        }
        const newStock = p.stock - item.qty;
        tx.update(pRef, { stock: newStock, availability: newStock > 0 ? p.availability : false });
      }
    }
    tx.update(orderRef, {
      paymentStatus: "paid",
      orderStatus: "proc",
      paymentMethod: method === "tunai" ? "cash" : "debit",
      paidAt: admin.firestore.FieldValue.serverTimestamp(),
      paidBy: req.auth.uid,
      paidByName: req.auth.token.name || req.auth.token.email || req.auth.uid,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });

  await writeAudit(req.auth.uid, req.auth.token.name, `Konfirmasi bayar (${method})`, orderId);
  return { ok: true };
});

// ---------------------------------------------------------------------
// Transisi status pesanan oleh kasir
// ---------------------------------------------------------------------
const TRANSITIONS = { proc: "ready", ready: "done" };

exports.advanceOrderStatus = onCall(async (req) => {
  requireStaff(req.auth);
  const { orderId } = req.data || {};
  const orderRef = db.collection("orders").doc(orderId);
  const snap = await orderRef.get();
  if (!snap.exists) throw new HttpsError("not-found", "Pesanan tidak ditemukan.");
  const current = snap.data().orderStatus;
  const next = TRANSITIONS[current];
  if (!next) throw new HttpsError("failed-precondition", `Tidak bisa mengubah status dari ${current}.`);
  await orderRef.update({ orderStatus: next, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  await writeAudit(req.auth.uid, req.auth.token.name, `Status → ${next}`, orderId);
  return { ok: true, orderStatus: next };
});

exports.cancelOrder = onCall(async (req) => {
  requireStaff(req.auth);
  const { orderId, reason } = req.data || {};
  const orderRef = db.collection("orders").doc(orderId);
  const snap = await orderRef.get();
  if (!snap.exists) throw new HttpsError("not-found", "Pesanan tidak ditemukan.");
  if (snap.data().orderStatus !== "wait") {
    throw new HttpsError("failed-precondition", "Hanya pesanan yang belum dibayar yang bisa dibatalkan langsung. Pesanan lain butuh proses refund manual.");
  }
  await orderRef.update({
    orderStatus: "cancel",
    cancelReason: reason || null,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  await writeAudit(req.auth.uid, req.auth.token.name, "Batalkan pesanan" + (reason ? `: ${reason}` : ""), orderId);
  return { ok: true };
});

// ---------------------------------------------------------------------
// Menu & stok (kasir/admin)
// ---------------------------------------------------------------------
exports.setAvailability = onCall(async (req) => {
  requireStaff(req.auth);
  const { productId, availability } = req.data || {};
  await db.collection("products").doc(String(productId)).update({ availability: !!availability });
  await writeAudit(req.auth.uid, req.auth.token.name, `${availability ? "Tersedia" : "Habis"}: produk ${productId}`);
  return { ok: true };
});

exports.editProduct = onCall(async (req) => {
  requireAdmin(req.auth);
  const { productId, price, stock } = req.data || {};
  const patch = {};
  if (typeof price === "number" && price >= 0) patch.price = price;
  if (stock === null || (typeof stock === "number" && stock >= 0)) {
    patch.stock = stock;
    if (stock === 0) patch.availability = false;
  }
  if (!Object.keys(patch).length) throw new HttpsError("invalid-argument", "Tidak ada perubahan valid.");
  await db.collection("products").doc(String(productId)).update(patch);
  await writeAudit(req.auth.uid, req.auth.token.name, `Edit produk ${productId}`);
  return { ok: true };
});

exports.setStockMode = onCall(async (req) => {
  requireAdmin(req.auth);
  const { mode } = req.data || {};
  if (!["auto", "manual"].includes(mode)) throw new HttpsError("invalid-argument", "Mode tidak dikenal.");
  await db.collection("settings").doc("general").set({ stockMode: mode }, { merge: true });
  await writeAudit(req.auth.uid, req.auth.token.name, `Mode stok: ${mode}`);
  return { ok: true };
});

// ---------------------------------------------------------------------
// Manajemen staf (admin only) — memberi custom claim role via Admin SDK.
// Login sesungguhnya tetap lewat Firebase Authentication (mis. email/
// password) yang dibuat dulu di Firebase Console atau lewat fungsi ini.
// ---------------------------------------------------------------------
exports.setStaffRole = onCall(async (req) => {
  requireAdmin(req.auth);
  const { uid, role, name } = req.data || {};
  if (!uid || !["kasir", "admin"].includes(role)) {
    throw new HttpsError("invalid-argument", "uid dan role (kasir/admin) wajib diisi.");
  }
  await admin.auth().setCustomUserClaims(uid, { role, name: name || null });
  await db.collection("users").doc(uid).set({ role, name: name || null, active: true }, { merge: true });
  await writeAudit(req.auth.uid, req.auth.token.name, `Set role ${uid} → ${role}`);
  return { ok: true };
});
