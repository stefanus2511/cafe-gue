/**
 * Menjadikan satu akun sebagai Admin pertama kali (sebelum ada admin lain
 * yang bisa memanggil fungsi setStaffRole). Jalankan SEKALI.
 *
 * Cara pakai:
 *   1. Buat user-nya dulu di Firebase Console → Authentication → Add user
 *      (isi email & password kasir/admin pertama).
 *   2. Salin UID user tsb dari halaman Authentication.
 *   3. node scripts/bootstrap-admin.js <UID> <nama>
 */
const admin = require("firebase-admin");
const sa = require("./serviceAccountKey.json");
admin.initializeApp({ credential: admin.credential.cert(sa) });

const [, , uid, name] = process.argv;
if (!uid) { console.error("Pakai: node scripts/bootstrap-admin.js <UID> <nama>"); process.exit(1); }

admin.auth().setCustomUserClaims(uid, { role: "admin", name: name || "Admin" })
  .then(() => admin.firestore().collection("users").doc(uid).set({ role: "admin", name: name || "Admin", active: true }, { merge: true }))
  .then(() => { console.log("UID", uid, "sekarang Admin. Minta mereka logout & login ulang."); process.exit(0); });
