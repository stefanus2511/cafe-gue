/**
 * Jalankan SEKALI untuk mengisi data awal (menu contoh + meja).
 * Cara pakai:
 *   1. Download service account key dari Firebase Console
 *      (Project settings → Service accounts → Generate new private key)
 *      dan simpan sebagai scripts/serviceAccountKey.json (JANGAN di-commit).
 *   2. npm install firebase-admin   (di dalam folder scripts, atau folder root)
 *   3. node scripts/seed.js
 */
const admin = require("firebase-admin");
const sa = require("./serviceAccountKey.json");
admin.initializeApp({ credential: admin.credential.cert(sa) });
const db = admin.firestore();

const products = [
  { id: "1", name: "Espresso", description: "Shot tunggal, pekat dan bersih.", price: 18000, category: "Coffee", color: "#3B2A20", availability: true, stock: null,
    variants: [{ name: "Ukuran", choices: [{ label: "Single", priceDelta: 0 }, { label: "Double", priceDelta: 8000 }] }] },
  { id: "2", name: "Caffe Latte", description: "Espresso dengan susu steam lembut.", price: 28000, category: "Coffee", color: "#6F4E37", availability: true, stock: null,
    variants: [{ name: "Ukuran", choices: [{ label: "Regular", priceDelta: 0 }, { label: "Large", priceDelta: 6000 }] },
               { name: "Suhu", choices: [{ label: "Panas", priceDelta: 0 }, { label: "Es", priceDelta: 0 }] }] },
  { id: "3", name: "Kopi Susu Gula Aren", description: "Signature: gula aren dan susu segar.", price: 26000, category: "Signature", color: "#8B5E3C", availability: true, stock: null,
    variants: [{ name: "Topping", choices: [{ label: "Tanpa", priceDelta: 0 }, { label: "Boba", priceDelta: 5000 }] }] },
  { id: "4", name: "Matcha Latte", description: "Matcha Uji dengan susu.", price: 30000, category: "Non-Coffee", color: "#5b6b3a", availability: true, stock: null, variants: [] },
  { id: "5", name: "Earl Grey", description: "Teh hitam bergamot.", price: 22000, category: "Tea", color: "#7a5c46", availability: true, stock: null, variants: [] },
  { id: "6", name: "Butter Croissant", description: "Berlapis, dipanggang pagi ini.", price: 24000, category: "Pastry", color: "#b98a54", availability: true, stock: 12, variants: [] },
  { id: "7", name: "Nasi Ayam Sambal Matah", description: "Ayam suwir, nasi hangat, sambal matah.", price: 38000, category: "Food", color: "#a4552f", availability: true, stock: null, variants: [] },
  { id: "8", name: "Tiramisu Slice", description: "Mascarpone, kopi, kakao.", price: 34000, category: "Dessert", color: "#4a382c", availability: false, stock: 0, variants: [] },
];

async function main() {
  const batch = db.batch();
  products.forEach((p) => batch.set(db.collection("products").doc(p.id), p));
  for (let i = 1; i <= 12; i++) {
    batch.set(db.collection("tables").doc(String(i)), { tableNumber: i, active: true, qrIdentifier: `table-${i}` });
  }
  batch.set(db.collection("settings").doc("general"), { stockMode: "auto" });
  batch.set(db.collection("settings").doc("counters"), { orderSeq: 0 });
  await batch.commit();
  console.log("Selesai mengisi data awal.");
}
main();
