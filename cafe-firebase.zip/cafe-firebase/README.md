# Kopi Kita — Tahap 2 (Firebase)

Struktur ini menggantikan localStorage pada prototipe sebelumnya dengan
Firestore + Cloud Functions, supaya harga, stok, dan status pembayaran
divalidasi di server, bukan di browser.

## 1. Persiapan akun & CLI
```bash
npm install -g firebase-tools
firebase login
```
Project `cafe-gue` (dari config yang Anda kirim) harus sudah ada di
[console.firebase.google.com](https://console.firebase.google.com). Di
project itu, aktifkan: **Firestore Database**, **Authentication** (metode
Email/Password), **Functions**, dan **Hosting**. Functions butuh paket
berbayar **Blaze** (tetap gratis untuk trafik kecil, tapi wajib upgrade dari
paket Spark).

## 2. Isi kunci rahasia
```bash
cp functions/.env.example functions/.env
```
Buka `functions/.env` dan isi:
- `CAFE_QRIS_STATIC` — **ganti dengan QRIS statis milik café**, bukan yang
  dari foto sebelumnya (itu terdaftar atas nama bisnis lain).
- `QRISKU_API_KEY`, `QRISKU_BASE_URL` — isi setelah Anda mendaftar di
  qrisku.my.id. Sebelum diisi, sistem tetap berjalan tapi status QRIS akan
  selalu "menunggu" (tidak pernah otomatis lunas) — Tandai kalau Anda ingin
  bagian ini disimulasikan dulu seperti prototipe sebelumnya.

## 3. Isi data awal & admin pertama
```bash
cd scripts
npm install firebase-admin
# taruh serviceAccountKey.json di folder ini (lihat komentar di tiap file)
node seed.js
node bootstrap-admin.js <UID_dari_Authentication> "Nama Admin"
```

## 4. Deploy
```bash
firebase deploy --only firestore:rules,functions,hosting
```
Setelah itu situs bisa diakses di `https://cafe-gue.web.app` — halaman
`/`, `/admin.html`, `/tv.html`.

## 5. Menambah kasir
Login sebagai admin di `/admin.html`, lalu buat user baru lewat Firebase
Console → Authentication, catat UID-nya, dan jalankan fungsi `setStaffRole`
(lewat halaman admin nanti, atau sementara lewat `bootstrap-admin.js` dengan
role diubah manual) untuk memberi peran `kasir`.

## Yang BELUM ada / perlu Anda sesuaikan
- **Endpoint qrisku.my.id** di `functions/index.js` (fungsi `pollQrisPayment`
  dan `pollQrisPaymentScheduled`) memakai path dan bentuk response tebakan,
  karena dokumentasi resminya tidak bisa saya baca dari sini. Cari bagian
  bertanda `TODO` dan sesuaikan dengan dokumentasi asli setelah Anda punya
  akun.
- **Struk PDF** belum dibuat di tahap ini.
- **Tampilan QR di halaman pelacakan** masih menampilkan teks payload QRIS
  mentah, belum digambar sebagai kode QR visual.
- Login admin pertama masih manual lewat script (`bootstrap-admin.js`)
  karena tidak ada admin lain yang bisa memberi peran sebelumnya.
