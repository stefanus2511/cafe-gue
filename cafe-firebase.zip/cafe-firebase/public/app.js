import { db, functions } from "./firebase-config.js";
import {
  collection, doc, onSnapshot, query, where,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";
import { httpsCallable } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-functions.js";

const $ = (s) => document.querySelector(s);
const R = (n) => "Rp" + Number(n || 0).toLocaleString("id-ID");
const CFG = { name: "Kopi Kita", tables: 12 };
const ST = { wait: "Menunggu Pembayaran", proc: "Proses", ready: "Siap", done: "Selesai", cancel: "Dibatalkan" };

const createOrder = httpsCallable(functions, "createOrder");
const pollQrisPayment = httpsCallable(functions, "pollQrisPayment");

let products = [];
let cart = [];
let table = +localStorage.getItem("kk.table") || 0;
let cat = "Semua";
let ui = {};
let pollTimer = null;

// --- Realtime katalog produk ---------------------------------------------
onSnapshot(collection(db, "products"), (snap) => {
  products = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  draw();
}, (err) => {
  console.error(err);
  $("#app").innerHTML = `<div class="wrap"><p class="err">Gagal memuat menu. Periksa koneksi internet Anda.</p></div>`;
});

function cats() {
  return ["Semua", ...new Set(products.map((p) => p.category))];
}
function totals(items) {
  const sub = items.reduce((a, i) => a + i.price * i.qty, 0);
  const tax = Math.round(sub * 0.1);
  return { sub, tax, total: sub + tax };
}

function route() { return location.hash.replace("#/", "") || ""; }
addEventListener("hashchange", draw);

function draw() {
  const trackId = localStorage.getItem("kk.myOrder");
  if (ui.view === "track" && trackId) return renderTrack(trackId);

  const qty = cart.reduce((a, i) => a + i.qty, 0);
  const t = totals(cart);
  const list = products
    .filter((p) => cat === "Semua" || p.category === cat)
    .filter((p) => !ui.q || p.name.toLowerCase().includes(ui.q.toLowerCase()));

  $("#app").innerHTML = `
  <div class="bar"><div class="wrap">
    <b>${CFG.name}</b>
    <button class="g" onclick="document.getElementById('meja').scrollIntoView({behavior:'smooth'})">${table ? "Meja " + table : "Pilih meja"}</button>
    <button class="g" onclick="window.__ui.s=!window.__ui.s;window.__draw()">Cari</button>
    <button onclick="window.__ui.dr='cart';window.__draw()">Keranjang ${qty}</button>
  </div></div>
  <div class="wrap">
    ${ui.s ? `<input style="width:100%;margin-top:12px" placeholder="Cari menu…" value="${ui.q || ""}" oninput="window.__ui.q=this.value;window.__draw()" autofocus>` : ""}
    <section class="hero"><h1>Your Daily Coffee, Crafted Differently</h1>
      <p>Pilih meja, pesan dari HP, dan kami antar saat siap.</p>
      <button onclick="document.getElementById('menu').scrollIntoView({behavior:'smooth'})">Explore Menu</button>
    </section>
    <section id="meja" class="tb"><h2>Pilih meja Anda</h2>
      <div class="tg">${Array.from({ length: CFG.tables }, (_, i) => `<button class="${table == i + 1 ? "on" : ""}" onclick="window.__setTable(${i + 1})">${i + 1}</button>`).join("")}</div>
    </section>
    <div id="menu" class="chips">${cats().map((c) => `<button class="${c == cat ? "on" : ""}" onclick="window.__setCat('${c}')">${c}</button>`).join("")}</div>
    <div class="grid">${list.map(cardHtml).join("") || "<p>Menu tidak ditemukan.</p>"}</div>
  </div>
  ${qty && !ui.dr ? `<div class="sticky"><span><b>${R(t.total)}</b> · ${qty} item</span><button onclick="window.__ui.dr='cart';window.__draw()">Lihat Keranjang</button></div>` : ""}
  ${ui.dr === "item" ? itemDrawerHtml() : ui.dr === "cart" ? cartDrawerHtml() : ""}
  <p style="text-align:center;font-size:12px;color:var(--mu);padding:0 16px 90px">
    <a href="admin.html">Kasir</a> · <a href="tv.html">TV</a></p>`;
}

function cardHtml(p) {
  const out = !p.availability;
  return `<div class="card ${out ? "out" : ""}" ${out ? "" : `onclick="window.__openItem('${p.id}')"`}>
    <div class="ph" style="background:linear-gradient(135deg,${p.color || "#6F4E37"},${p.color || "#6F4E37"}cc)">${p.name[0]}</div>
    <div class="b"><b>${p.name}</b><p>${p.description || ""}</p>
      <div class="row"><span class="pr">${R(p.price)}</span>${out ? '<span class="tag">Habis</span>' : '<span class="tag">Tambah</span>'}</div>
    </div></div>`;
}

function itemDrawerHtml() {
  const p = products.find((x) => x.id === ui.it.id);
  if (!p) return "";
  const it = ui.it;
  const variants = p.variants || [];
  const price = p.price + variants.reduce((a, g, i) => a + (g.choices[it.sel[i]]?.priceDelta || 0), 0);
  return `<div class="dr" onclick="if(event.target==this){window.__ui.dr=0;window.__draw()}"><div>
    <div class="ph" style="border-radius:16px;background:${p.color || "#6F4E37"}">${p.name[0]}</div>
    <h2 style="margin-top:12px">${p.name}</h2><p>${p.description || ""}</p>
    ${variants.map((g, i) => `<div><b>${g.name}</b><br>${g.choices.map((c, j) => `<label style="display:inline-flex;gap:6px;margin:4px 8px 4px 0;padding:8px 12px;border-radius:99px;background:var(--cr);font-size:14px">
      <input type="radio" name="g${i}" ${it.sel[i] == j ? "checked" : ""} onchange="window.__ui.it.sel[${i}]=${j};window.__draw()"> ${c.label}${c.priceDelta ? " +" + R(c.priceDelta) : ""}</label>`).join("")}</div>`).join("")}
    <textarea style="width:100%;margin-top:10px" placeholder="Catatan khusus" oninput="window.__ui.it.note=this.value">${it.note || ""}</textarea>
    <div class="row"><span><button class="g" onclick="window.__ui.it.qty=Math.max(1,window.__ui.it.qty-1);window.__draw()">−</button> <b>${it.qty}</b> <button class="g" onclick="window.__ui.it.qty++;window.__draw()">+</button></span>
      <button onclick="window.__addToCart(${price})">Tambah ${R(price * it.qty)}</button></div>
  </div></div>`;
}

function cartDrawerHtml() {
  const t = totals(cart);
  return `<div class="dr" onclick="if(event.target==this){window.__ui.dr=0;window.__draw()}"><div>
    <h2>Pesanan${table ? " · Meja " + table : ""}</h2>
    ${!table ? `<div class="note">Pilih meja dulu di bagian atas halaman.</div>` : ""}
    ${cart.map((i, x) => `<div class="row"><span><b>${i.name}</b><br><small>${i.opts || ""}${i.note ? " · " + i.note : ""}</small></span>
      <span><button class="g" onclick="window.__cartQty(${x},-1)">−</button> ${i.qty} <button class="g" onclick="window.__cartQty(${x},1)">+</button></span></div>`).join("") || "<p>Keranjang kosong.</p>"}
    <hr><div class="row"><span>Subtotal</span><span>${R(t.sub)}</span></div>
    <div class="row"><span>Pajak 10%</span><span>${R(t.tax)}</span></div>
    <div class="row"><b>Total</b><b>${R(t.total)}</b></div>
    <p><b>Metode pembayaran</b></p>
    <div class="row"><label><input type="radio" name="pm" ${ui.pm !== "qris" ? "checked" : ""} onchange="window.__ui.pm='cash'"> Bayar di Kasir</label>
      <label><input type="radio" name="pm" ${ui.pm === "qris" ? "checked" : ""} onchange="window.__ui.pm='qris'"> QRIS</label></div>
    ${ui.err ? `<div class="err">${ui.err}</div>` : ""}
    <div class="row"><button class="g" onclick="window.__ui.dr=0;window.__draw()">Tutup</button>
      <button ${cart.length && table ? "" : "disabled"} onclick="window.__placeOrder()">Konfirmasi Pesanan</button></div>
  </div></div>`;
}

// --- Aksi (dipasang ke window supaya bisa dipanggil dari onclick) --------
window.__draw = draw;
window.__ui = ui;
window.__setTable = (n) => { table = n; localStorage.setItem("kk.table", n); draw(); };
window.__setCat = (c) => { cat = c; draw(); };
window.__openItem = (id) => {
  const p = products.find((x) => x.id === id);
  ui.it = { id, qty: 1, sel: (p.variants || []).map(() => 0), note: "" };
  ui.dr = "item"; draw();
};
window.__addToCart = (price) => {
  const p = products.find((x) => x.id === ui.it.id);
  const opts = (p.variants || []).map((g, i) => g.choices[ui.it.sel[i]].label).join(", ");
  cart.push({ productId: p.id, variantChoices: ui.it.sel, name: p.name, opts, qty: ui.it.qty, price, note: ui.it.note });
  ui.dr = 0; draw();
};
window.__cartQty = (idx, d) => {
  cart[idx].qty += d;
  if (cart[idx].qty <= 0) cart.splice(idx, 1);
  draw();
};

window.__placeOrder = async () => {
  ui.err = "";
  const btn = event.target; btn.disabled = true; btn.textContent = "Memproses…";
  try {
    const res = await createOrder({
      tableId: table,
      items: cart.map((i) => ({ productId: i.productId, qty: i.qty, variantChoices: i.variantChoices, note: i.note })),
      paymentMethod: ui.pm === "qris" ? "qris" : "cash",
    });
    localStorage.setItem("kk.myOrder", res.data.orderId);
    cart = [];
    ui.dr = 0; ui.view = "track";
    draw();
  } catch (e) {
    ui.err = e.message || "Gagal membuat pesanan. Coba lagi.";
    draw();
  }
};

// --- Pelacakan pesanan -----------------------------------------------------
let trackUnsub = null;
function renderTrack(orderId) {
  if (trackUnsub) { trackUnsub(); trackUnsub = null; }
  trackUnsub = onSnapshot(doc(db, "orders", orderId), (snap) => {
    if (!snap.exists()) { $("#app").innerHTML = `<div class="wrap"><p class="err">Pesanan tidak ditemukan.</p></div>`; return; }
    const o = snap.data();
    renderTrackHtml(orderId, o);
    if (o.orderStatus !== "wait" && pollTimer) { clearInterval(pollTimer); pollTimer = null; }
    if (o.orderStatus === "wait" && o.paymentMethod === "qris" && !pollTimer) {
      pollTimer = setInterval(() => pollQrisPayment({ orderId }).catch(() => {}), 5000);
    }
  });
}

function renderTrackHtml(orderId, o) {
  const steps = ["wait", "proc", "ready", "done"];
  const ix = steps.indexOf(o.orderStatus);
  $("#app").innerHTML = `<div class="wrap" style="max-width:520px;padding-top:20px">
    <button class="g" onclick="window.__backToMenu()">← Menu</button>
    <h1 style="margin:16px 0 4px">${o.orderNumber}</h1>
    <p>Meja ${o.tableId}</p>
    <div class="prog">${steps.map((s, i) => `<span class="${o.orderStatus !== "cancel" && i <= ix ? "on" : ""}"></span>`).join("")}</div>
    <h2>${ST[o.orderStatus]}</h2>
    ${o.orderStatus === "wait" && o.paymentMethod === "qris" && o.qrisString ? `
      <div class="rc" style="text-align:center">
        <span class="stamp" style="color:var(--wn)">QRIS · SCAN UNTUK BAYAR</span>
        <div id="qrbox" style="margin:12px auto;width:200px;height:200px;background:#fff;display:grid;place-items:center;font-size:11px;color:#999;word-break:break-all;padding:8px">Memuat QR…</div>
        <b>${R(o.total)}</b>
        <p><small>Halaman ini otomatis diperbarui begitu pembayaran terkonfirmasi.</small></p>
      </div>` : o.orderStatus === "wait" ? `<p>Tunjukkan nomor ini ke kasir dan bayar. Pesanan masuk dapur setelah pembayaran dikonfirmasi.</p>` : ""}
    ${o.orderStatus === "ready" ? `<div class="note" style="font-size:16px">Pesanan Anda siap diambil!</div>` : ""}
    <div class="rc" style="margin-top:16px">
      <span class="stamp" style="color:${o.paymentStatus === "paid" ? "var(--ok)" : "var(--er)"}">${o.paymentStatus === "paid" ? "LUNAS" : "BELUM DIBAYAR"}</span>
      ${o.items.map((i) => `<div class="row"><span>${i.qty}× ${i.name}<br><small>${i.opts || ""}</small></span><span>${R(i.price * i.qty)}</span></div>`).join("")}
      <hr><div class="row"><span>Pajak</span><span>${R(o.tax)}</span></div>
      <div class="row"><b>Total</b><b>${R(o.total)}</b></div>
    </div>
  </div>`;
  if (o.qrisString) renderQrPlaceholder(o.qrisString);
}

// Menampilkan payload QRIS mentah (bisa diganti pustaka QR-image jika perlu tampilan QR asli).
function renderQrPlaceholder(payload) {
  const box = $("#qrbox");
  if (box) box.textContent = payload;
}

window.__backToMenu = () => {
  ui.view = 0;
  if (trackUnsub) { trackUnsub(); trackUnsub = null; }
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  draw();
};

// Buka langsung ke tracking kalau ada pesanan tersimpan dan belum selesai.
if (localStorage.getItem("kk.myOrder")) ui.view = "track";
draw();
