// Konfigurasi ini aman ditaruh di frontend (bukan secret key) — begitu cara
// kerja Firebase Web SDK. Yang harus dijaga kerahasiaannya (API key qrisku,
// dll) ada di functions/.env, BUKAN di sini.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";
import { getFunctions } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-functions.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyBLHND286c_gslo_P7y12A-YM8ElL0SnP8",
  authDomain: "cafe-gue.firebaseapp.com",
  projectId: "cafe-gue",
  storageBucket: "cafe-gue.firebasestorage.app",
  messagingSenderId: "1010996323532",
  appId: "1:1010996323532:web:cfd5ce7182944bcb86ce69",
  measurementId: "G-7JF17YSPJS",
};

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const functions = getFunctions(app, "asia-southeast2");
export const auth = getAuth(app);
