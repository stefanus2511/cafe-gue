import { db } from "./firebase-config.js";
import {
  collection, onSnapshot, query, where,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";

const $ = (s) => document.querySelector(s);

function draw(procOrders, readyOrders) {
  $("#app").innerHTML = `<div class="tv">
    <h2>Kopi Kita</h2>
    <div class="cols">
      <div><h2>Sedang Diproses</h2>${procOrders.map((o) => `<span class="n">${o.orderNumber}</span>`).join("")}</div>
      <div><h2>Siap Diambil</h2>${readyOrders.map((o) => `<span class="n">${o.orderNumber}</span>`).join("")}</div>
    </div>
  </div>`;
}

let proc = [], ready = [];
onSnapshot(query(collection(db, "orders"), where("orderStatus", "==", "proc")), (snap) => {
  proc = snap.docs.map((d) => d.data());
  draw(proc, ready);
});
onSnapshot(query(collection(db, "orders"), where("orderStatus", "==", "ready")), (snap) => {
  ready = snap.docs.map((d) => d.data());
  draw(proc, ready);
});
