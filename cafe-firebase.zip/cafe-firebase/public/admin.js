import { db, functions, auth } from "./firebase-config.js";
import {
  collection, onSnapshot, orderBy, query,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";
import { httpsCallable } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-functions.js";
import {
  onAuthStateChanged, signInWithEmailAndPassword, signOut,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";

const $ = (s) => document.querySelector(s);
const R = (n) => "Rp" + Number(n || 0).toLocaleString("id-ID");
const ST = { wait: "Menunggu Pembayaran", proc: "Proses", ready: "Siap", done: "Selesai", cancel: "Dibatalkan" };
const PM = { cash: "Tunai", debit: "Debit", qris: "QRIS" };
const RANK = { proc: 0, wait: 1, ready: 2, done: 3, cancel: 4 };

const confirmCashPayment = httpsCallable(functions, "confirmCashPayment");
const advanceOrderStatus = httpsCallable(functions, "advanceOrderStatus");
const cancelOrderFn = httpsCallable(functions, "cancelOrder");
const setAvailability = httpsCallable(functions, "setAvailability");
const editProductFn = httpsCallable(functions, "editProduct");
const setStockModeFn = httpsCallable(functions, "setStockMode");

let user = null, role = null, name = "";
let orders = [], products = [], settings = {};
let kv = "dashboard", kf = "aktif", kq = "", kd = null;

// --- Login -----------------------------------------------------------------
onAuthStateChanged(auth, async (u) => {
  user = u;
  if (u) {
    const tok = await u.getIdTokenResult(true);
    role = tok.claims.role || null;
    name = tok.claims.name || u.email;
  } else { role = null; }
  draw();
});

function loginScreen(err) {
  return `<div class="wrap" style="max-width:380px;padding-top:80px">
    <h1>Masuk Kasir</h1>
    <p class="note">Akun kasir/admin dibuat oleh admin lewat Firebase Authentication + fungsi setStaffRole. Prototipe ini tidak menyediakan pendaftaran mandiri.</p>
    ${err ? `<div class="err">${err}</div>` : ""}
    <p>Email<br><input id="em" type="email" style="width:100%" autocomplete="username"></p>
    <p>Kata sandi<br><input id="pw" type="password" style="width:100%" autocomplete="current-password"></p>
    <button style="width:100%" onclick="window.__login()">Masuk</button>
  </div>`;
}
window.__login = async () => {
  try {
    await signInWithEmailAndPassword(auth, $("#em").value, $("#pw").value);
  } catch (e) {
    $("#app").innerHTML = loginScreen("Email atau kata sandi salah.");
  }
};
window.__logout = () => signOut(auth);

// --- Data realtime -----------------------------------------------------------
function subscribeData() {
  onSnapshot(query(collection(db, "orders"), orderBy("createdAt", "desc")), (snap) => {
    orders = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    draw();
  });
  onSnapshot(collection(db, "products"), (snap) => {
    products = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    draw();
  });
  onSnapshot(collection(db, "settings"), (snap) => {
    snap.docs.forEach((d) => (settings[d.id] = d.data()));
    draw();
  });
}
let subscribed = false;

function draw() {
  if (!user || !role) { $("#app").innerHTML = loginScreen(); return; }
  if (!subscribed) { subscribed = true; subscribeData(); }

  const today = new Date().toDateString();
  const todays = orders.filter((o) => o.createdAt?.toDate?.().toDateString() === today);
  const isAdmin = role === "admin";
  const count = (s) => orders.filter((o) => o.orderStatus === s).length;
  const active = (o) => ["wait", "proc", "ready"].includes(o.orderStatus);
  const matches = (o, q) => !q || (o.orderNumber + " " + o.tableId + " " + o.items.map((i) => i.name).join(" ")).toLowerCase().includes(q.toLowerCase());
  const fdt = (ts) => ts?.toDate ? ts.toDate().toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "-";

  const stats = `<div class="st">
    <div><b>${todays.length}</b>Pesanan hari ini</div>
    <div><b>${count("wait")}</b>Menunggu pembayaran</div>
    <div><b>${count("proc")}</b>Diproses</div>
    <div><b>${count("ready")}</b>Siap diambil</div>
    <div><b>${orders.filter((o) => o.paymentStatus === "paid").length}</b>Transaksi berhasil</div>
  </div>`;

  const orderCard = (o) => `<div class="oc ${o.orderStatus}">
    <div class="row"><b>${o.orderNumber} · Meja ${o.tableId}</b><span class="tag">${ST[o.orderStatus]} · ${o.paymentStatus === "paid" ? "Lunas " + (PM[o.paymentMethod] || "") : "Belum bayar"}</span></div>
    <small>${fdt(o.createdAt)} · ${o.items.reduce((a, i) => a + i.qty, 0)} item</small>
    ${o.items.map((i) => `<div>${i.qty}× ${i.name} <small>${i.opts || ""}${i.note ? " · " + i.note : ""}</small></div>`).join("")}
    <div class="row"><b>${R(o.total)}</b><span>
      ${o.orderStatus === "wait" && o.paymentMethod === "cash" ? `<button onclick='window.__dlg("pay","${o.id}")'>Konfirmasi Pembayaran</button> <button class="r" onclick="window.__cancel('${o.id}')">Batalkan</button>` : ""}
      ${o.orderStatus === "wait" && o.paymentMethod === "qris" ? `<small>Menunggu QRIS…</small> <button class="r" onclick="window.__cancel('${o.id}')">Batalkan</button>` : ""}
      ${o.orderStatus === "proc" ? `<button onclick="window.__advance('${o.id}')">Tandai Siap</button>` : ""}
      ${o.orderStatus === "ready" ? `<button onclick="window.__advance('${o.id}')">Tandai Selesai</button>` : ""}
    </span></div></div>`;

  let body = "";
  if (kv === "dashboard") {
    body = stats + `<h3>Perlu tindakan</h3>` + (orders.filter(active).sort((a, b) => RANK[a.orderStatus] - RANK[b.orderStatus]).slice(0, 6).map(orderCard).join("") || "<p>Belum ada pesanan aktif.</p>");
  } else if (kv === "pesanan") {
    const list = orders.filter((o) => (kf === "aktif" ? active(o) : kf === "semua" || o.orderStatus === kf) && matches(o, kq)).sort((a, b) => RANK[a.orderStatus] - RANK[b.orderStatus]);
    body = stats + `<div class="chips">${[["aktif", "Aktif"], ["wait", "Menunggu"], ["proc", "Proses"], ["ready", "Siap"], ["done", "Selesai"], ["cancel", "Dibatalkan"], ["semua", "Semua"]].map((f) => `<button class="${kf == f[0] ? "on" : ""}" onclick="window.__setF('${f[0]}')">${f[1]}</button>`).join("")}</div>` + (list.map(orderCard).join("") || "<p>Tidak ada pesanan.</p>");
  } else if (kv === "stok") {
    body = `<div class="row"><h3>Menu & Stok</h3>${isAdmin ? `<select onchange="window.__mode(this.value)"><option value="auto" ${(settings.general?.stockMode || "auto") == "auto" ? "selected" : ""}>Otomatis</option><option value="manual" ${settings.general?.stockMode == "manual" ? "selected" : ""}>Manual</option></select>` : `<span class="tag">${(settings.general?.stockMode || "auto") == "auto" ? "Otomatis" : "Manual"}</span>`}</div>` +
      products.map((p) => `<div class="oc row"><span><b>${p.name}</b> · ${R(p.price)}<br><small>${typeof p.stock === "number" ? "Stok: " + p.stock : "Tanpa hitungan stok"}</small></span>
        <span><span class="tag">${p.availability ? "Tersedia" : "Habis"}</span>
        <button class="g" onclick="window.__toggle('${p.id}',${!p.availability})">${p.availability ? "Tandai Habis" : "Tandai Tersedia"}</button>
        ${isAdmin ? `<button class="g" onclick='window.__dlg("edit","${p.id}")'>Edit</button>` : ""}</span></div>`).join("");
  } else if (kv === "riwayat") {
    const list = orders.filter((o) => matches(o, kq)).slice(0, 100);
    body = `<div class="st"><div><b>${list.length}</b>Transaksi ditampilkan</div><div><b>${R(list.filter((o) => o.paymentStatus === "paid").reduce((a, o) => a + o.total, 0))}</b>Total terbayar</div></div>
      ${isAdmin ? `<button class="g" onclick="window.__csv()">Ekspor CSV</button>` : ""}
      <div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:14px">
      <tr><th style="text-align:left;padding:8px">No</th><th style="text-align:left;padding:8px">Waktu</th><th style="text-align:left;padding:8px">Meja</th><th style="text-align:left;padding:8px">Metode</th><th style="text-align:left;padding:8px">Total</th><th style="text-align:left;padding:8px">Status</th></tr>
      ${list.map((o) => `<tr style="border-top:1px solid var(--cr)"><td style="padding:8px">${o.orderNumber}</td><td style="padding:8px">${fdt(o.createdAt)}</td><td style="padding:8px">${o.tableId}</td><td style="padding:8px">${PM[o.paymentMethod] || "-"}</td><td style="padding:8px">${R(o.total)}</td><td style="padding:8px">${ST[o.orderStatus]}</td></tr>`).join("")}
      </table></div>`;
  }

  const dlg = kd ? dialogHtml() : "";
  $("#app").innerHTML = `<div class="k">
    <aside><h3 style="padding:8px 12px">Kopi Kita</h3>
      ${[["dashboard", "Dashboard"], ["pesanan", "Pesanan"], ["stok", "Menu & Stok"], ["riwayat", "Riwayat"]].map((t) => `<button class="${kv == t[0] ? "on" : ""}" onclick="window.__setV('${t[0]}')">${t[1]}</button>`).join("")}
      <button onclick="window.__logout()">Keluar (${name}${isAdmin ? " · Admin" : " · Kasir"})</button>
      <a href="index.html" style="color:var(--cr);font-size:13px">← Pelanggan</a>
    </aside>
    <main>
      <input placeholder="Cari pesanan…" value="${kq}" style="width:100%;margin-bottom:10px" oninput="window.__setQ(this.value)">
      ${body}
    </main>
  </div>${dlg}`;
}

function dialogHtml() {
  if (kd.t === "pay") {
    const o = orders.find((x) => x.id === kd.id);
    if (!o) return "";
    return `<div class="dr" onclick="if(event.target==this){window.__closeDlg()}"><div>
      <h2>Konfirmasi Pembayaran</h2><p>${o.orderNumber} · Meja ${o.tableId}</p>
      <h1>${R(o.total)}</h1><p>Terima jumlah ini dari pelanggan.</p>
      <div class="row"><label><input type="radio" name="m" checked onchange="window.__pm='tunai'"> Tunai</label><label><input type="radio" name="m" onchange="window.__pm='debit'"> Debit</label></div>
      <div class="row"><button class="g" onclick="window.__closeDlg()">Batal</button><button onclick="window.__pay('${o.id}')">Sudah Diterima</button></div>
    </div></div>`;
  }
  if (kd.t === "edit") {
    const p = products.find((x) => x.id === kd.id);
    if (!p) return "";
    return `<div class="dr" onclick="if(event.target==this){window.__closeDlg()}"><div>
      <h2>Edit ${p.name}</h2>
      <p>Harga (Rp)<br><input id="ep" type="number" min="0" value="${p.price}" style="width:100%"></p>
      <p>Stok (kosongkan jika tidak dihitung)<br><input id="es" type="number" min="0" value="${p.stock ?? ""}" style="width:100%"></p>
      <div class="row"><button class="g" onclick="window.__closeDlg()">Batal</button><button onclick="window.__saveEdit('${p.id}')">Simpan</button></div>
    </div></div>`;
  }
  return "";
}

// --- Aksi --------------------------------------------------------------------
window.__setV = (v) => { kv = v; draw(); };
window.__setF = (f) => { kf = f; draw(); };
window.__setQ = (q) => { kq = q; draw(); };
window.__dlg = (t, id) => { kd = { t, id }; window.__pm = "tunai"; draw(); };
window.__closeDlg = () => { kd = null; draw(); };

window.__pay = async (orderId) => {
  try { await confirmCashPayment({ orderId, method: window.__pm || "tunai" }); kd = null; draw(); }
  catch (e) { alert(e.message); }
};
window.__advance = async (orderId) => {
  try { await advanceOrderStatus({ orderId }); }
  catch (e) { alert(e.message); }
};
window.__cancel = async (orderId) => {
  if (!confirm("Batalkan pesanan ini?")) return;
  try { await cancelOrderFn({ orderId }); }
  catch (e) { alert(e.message); }
};
window.__toggle = async (productId, availability) => {
  try { await setAvailability({ productId, availability }); }
  catch (e) { alert(e.message); }
};
window.__mode = async (mode) => {
  try { await setStockModeFn({ mode }); }
  catch (e) { alert(e.message); }
};
window.__saveEdit = async (productId) => {
  const price = +$("#ep").value;
  const sv = $("#es").value;
  try {
    await editProductFn({ productId, price, stock: sv === "" ? null : +sv });
    kd = null; draw();
  } catch (e) { alert(e.message); }
};
window.__csv = () => {
  const rows = [["No", "Waktu", "Meja", "Metode", "Total", "Status"]].concat(
    orders.map((o) => [o.orderNumber, o.createdAt?.toDate?.().toISOString() || "", o.tableId, o.paymentMethod || "", o.total, o.orderStatus])
  );
  const a = document.createElement("a");
  a.href = "data:text/csv," + encodeURIComponent(rows.map((r) => r.join(",")).join("\n"));
  a.download = "transaksi.csv"; a.click();
};

draw();
